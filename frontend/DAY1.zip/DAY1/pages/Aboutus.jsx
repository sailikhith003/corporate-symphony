import Nav from "../components/Navbar";
function Aboutus() {
    return ( 
        <>
        <Nav/>
        <h1>
            ABOUT US
        </h1>
        </>
     );
}

export default Aboutus;