package com.example.event.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class BookedEventsModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookingId;
    private String eventName;
    private String imgURL;
    private String eventDescription;

    @JsonIgnore
    @OneToMany(mappedBy = "event", cascade = CascadeType.ALL)
    List<Applications> applications;

    public BookedEventsModel(int bookingId, String eventName,
            String eventDescription, String imgURL) {
        this.bookingId = bookingId;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.imgURL = imgURL;
    }

    public BookedEventsModel() {

    }

    public int getBookingId() {
        return bookingId;
    }

    public List<Applications> getApplications() {
        return this.applications;
    }

    public void setApplications(List<Applications> applications) {
        this.applications = applications;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public String getImgURL() {
        return this.imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    @Override
    public String toString() {
        return "BookedEvents [bookingId=" + bookingId + ", eventName=" + eventName + ", eventDescription="
                + eventDescription + "]";
    }

}
