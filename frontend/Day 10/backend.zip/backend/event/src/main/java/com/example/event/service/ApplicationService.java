package com.example.event.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.event.entity.Applications;
import com.example.event.entity.BookedEventsModel;
import com.example.event.repository.ApplicationRepository;
import com.example.event.repository.BookedEventsRep;

@Service
public class ApplicationService {
    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private BookedEventsRep bookedEventsRep;

    public String createApplication(Applications application, int id) {
        BookedEventsModel event = bookedEventsRep.findById(id).orElse(null);
        application.setEvent(event);
        List<Applications> appl = event.getApplications();
        appl.add(application);

        event.setApplications(appl);
        applicationRepository.save(application);
        bookedEventsRep.save(event);

        return "Application created";
    }

    public String approve(Long id, String amount, String venue) {
        Applications application = applicationRepository.findById(id).orElse(null);
        application.setAmount(amount);
        application.setVenue(venue);
        application.setStatus("Approved");
        applicationRepository.save(application);

        return "Application Approved";
    }

    public String reject(Long id) {
        Applications application = applicationRepository.findById(id).orElse(null);
        application.setStatus("Rejected");
        applicationRepository.save(application);
        return "Application Rejected";

    }
}
