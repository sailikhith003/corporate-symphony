package com.example.event.service;

import com.example.event.entity.Applications;
import com.example.event.entity.BookedEventsModel;
import com.example.event.repository.BookedEventsRep;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookedEventService {

    @Autowired
    private BookedEventsRep bookedEventsRepository;

    public List<BookedEventsModel> getAllBookedEvents() {
        return bookedEventsRepository.findAll();
    }

    public BookedEventsModel getBookedEventById(int id) {
        Optional<BookedEventsModel> optionalBookedEvent = bookedEventsRepository.findById(id);
        return optionalBookedEvent.orElse(null);
    }

    public BookedEventsModel createBookedEvent(BookedEventsModel bookedEvents) {
        return bookedEventsRepository.save(bookedEvents);
    }

    public BookedEventsModel updateBookedEvent(int id, BookedEventsModel bookedEvents) {
        bookedEvents.setBookingId(id);
        return bookedEventsRepository.save(bookedEvents);
    }

    public void deleteBookedEvent(int id) {
        bookedEventsRepository.deleteById(id);
    }

    public List<Applications> getApplications(int id) {
        BookedEventsModel event = bookedEventsRepository.findById(id).orElse(null);
        return event.getApplications();
    }

}
